
import {Request, Response} from "express";
import {ElasticController} from "../controller/ES_Controller";
import { inject } from "inversify";


export class Routes {

    public elastic_controller: ElasticController = new ElasticController();
    
    public routes(app): void {
        app.route('/get_customer_segmentation').get(this.elastic_controller.getData)
    }
}
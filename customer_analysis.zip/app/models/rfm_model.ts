
export class RFM_Model{
    "customer_id": string;
    "score":number;
    
    constructor(customer_id: string, score: number)
    {
        this.customer_id = customer_id;
        this.score = score ;
    }
}
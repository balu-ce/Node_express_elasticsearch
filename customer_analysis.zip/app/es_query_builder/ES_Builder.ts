import { injectable} from "inversify"; // library for implementing Dependency Injection
import * as esb from "elastic-builder";  //library for building elasticsearch query

export class ES_Query_Builder{

    public rfm_query()
    {
      // Several functions combined
        const rfm_score = esb.functionScoreQuery()
        .query(esb.matchAllQuery())
        .functions([
            esb.weightScoreFunction()
                .filter(esb.matchQuery('recency_cluster', "0"))
                .weight(1),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('recency_cluster', "1"))
                .weight(0.75),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('recency_cluster', "2"))
                .weight(0.50),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('recency_cluster', "3"))
                .weight(0.25),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "3"))
                .weight(1),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "2"))
                .weight(0.75),,
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "1"))
                .weight(0.50),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "0"))
                .weight(0.25),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "3"))
                .weight(1),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "2"))
                .weight(0.75),,
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "1"))
                .weight(0.50),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "0"))
                .weight(0.25)
        ])
        .scoreMode('sum')
        .boostMode('replace')
    
    return rfm_score;
    }

    public revenue_query()
    {
      // Several functions combined
        const revenue_score = esb.functionScoreQuery()
        .query(esb.matchAllQuery())
        .functions([
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "3"))
                .weight(1),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "2"))
                .weight(0.75),,
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "1"))
                .weight(0.50),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('revenue_cluster', "0"))
                .weight(0.25)
        ])
        .scoreMode('sum')
        .boostMode('replace')
    
    return revenue_score;
    }

    public frequency_query()
    {
      // Several functions combined
        const frequency_score = esb.functionScoreQuery()
        .query(esb.matchAllQuery())
        .functions([
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "3"))
                .weight(1),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "2"))
                .weight(0.75),,
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "1"))
                .weight(0.50),
            esb.weightScoreFunction()
                .filter(esb.matchQuery('frequency_cluster', "0"))
                .weight(0.25)
        ])
        .scoreMode('sum')
        .boostMode('replace')
    
    return frequency_score;
    }
}
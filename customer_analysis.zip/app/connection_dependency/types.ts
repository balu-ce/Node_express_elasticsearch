
const TYPES = {
    elasticsearch: Symbol.for("elasticsearch"),
    connection_Entity: Symbol.for("connection_Entity"),
};

export { TYPES };
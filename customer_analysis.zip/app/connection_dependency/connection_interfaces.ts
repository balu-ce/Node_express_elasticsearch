import {Client} from '@elastic/elasticsearch';

export interface elasticsearch{

    connection() : Client
}

export interface connection_Entity{

    es_connection() : Client
}
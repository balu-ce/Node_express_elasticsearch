import { injectable, inject } from "inversify";
import "reflect-metadata";
import { elasticsearch ,connection_Entity } from "./connection_interfaces";
import { TYPES } from "./types";
import {Client} from '@elastic/elasticsearch';

@injectable()
class ElasticsearchEntity implements elasticsearch {
  elastic_url : string = "http://localhost:9200"
    public connection() {
        return new Client({ node: this.elastic_url });
    }
}

@injectable()
class ConnectionEntity implements connection_Entity {
    private _es_conn: elasticsearch;
    public constructor(
	    @inject(TYPES.elasticsearch) es_conn: elasticsearch,
    ) {
        this._es_conn = es_conn;
    }
    public es_connection() {
    return this._es_conn.connection();
    }
}

export { ElasticsearchEntity, ConnectionEntity };
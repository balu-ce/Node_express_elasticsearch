import { myContainer } from "./inversify.config";
import { TYPES } from "./types";
import { connection_Entity } from "./connection_interfaces";

const es_obj = myContainer.get<connection_Entity>(TYPES.connection_Entity);

export {es_obj}



import { Container } from "inversify";
import { TYPES } from "./types";
import { elasticsearch , connection_Entity } from "./connection_interfaces";
import { ElasticsearchEntity , ConnectionEntity } from "./entities";
import {ES_Query_Builder} from "../es_query_builder/ES_Builder";

const myContainer = new Container();
myContainer.bind<elasticsearch>(TYPES.elasticsearch).to(ElasticsearchEntity);
myContainer.bind<connection_Entity>(TYPES.connection_Entity).to(ConnectionEntity);
//myContainer.bind<ES_Query_Builder>(ES_Query_Builder);
myContainer.bind<ES_Query_Builder>(ES_Query_Builder).toSelf()
export { myContainer };
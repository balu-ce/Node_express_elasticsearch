// Complete definition of the Search response
export interface ShardsResponse {
  total: number;
  successful: number;
  failed: number;
  skipped: number;
}

export interface Explanation {
  value: number;
  description: string;
  details: Explanation[];
}

export interface SearchResponse<T> {
  took: number;
  timed_out: boolean;
  _scroll_id?: string;
  _shards: ShardsResponse;
  hits: {
    total: number;
    max_score: number;
    hits: Array<{
      _index: string;
      _type: string;
      _id: string;
      _score: number;
      _source: T;
      _version?: number;
      _explanation?: Explanation;
      fields?: any;
      highlight?: any;
      inner_hits?: any;
      matched_queries?: string[];
      sort?: string[];
    }>;
  };
  aggregations?: any;
}



// Define the interface of the source object
export interface Source_rfmData {
  "customer_id": string;
  "recency": number;
  "recency_cluster": number;
  "frequency": number;
  "frequency_cluster": number;
  "revenue": number;
  "revenue_cluster": number;
  "day_diff": number;
  "day_diff1": number;
  "day_diff2": number;
  "day_diff_mean": number;
  "day_diff_std": number;
}

export interface rfm_data_array {
  [key: number]: Source_rfmData;
}
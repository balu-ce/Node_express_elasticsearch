import { Request, Response } from 'express';
import { es_obj } from "../connection_dependency/resolve_dependency";
import {SearchResponse, Source_rfmData } from "./elastic_interface";
import {ApiResponse, RequestParams} from '@elastic/elasticsearch';
import {ES_Query_Builder} from "../es_query_builder/ES_Builder";
import { RFM_Model } from '../models/rfm_model';
import { ErrorHandler } from '../handler/errorHandler';


export class ElasticController {
   
    constructor()
    {   }

    public async getData (req: Request, res: Response) {
     
      const es_query_builder = new ES_Query_Builder();
      
      try{
        const searchParams: RequestParams.Search = {
            index: 'rfm_data',
            body: {
              "query":es_query_builder.rfm_query().toJSON()
            }
          }
        
        
        // Craft the final type definition
        const response: ApiResponse<SearchResponse<Source_rfmData>> = await es_obj.es_connection().search(searchParams)
        const data = response.body.hits.hits.map((Source_rfmData)=>{
          return new RFM_Model(Source_rfmData._source.customer_id ,Source_rfmData._score ) ;
        })
        res.json(data)
      }
      catch(err){
        res.json(new ErrorHandler(err));
      }
    }
}
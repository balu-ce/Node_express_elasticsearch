
export class ErrorHandler
{
    public error:string;
    public success:boolean;
    public status_code : number;
    public message : string;

    constructor(err: string){
        this.error = err;
        this.success = false;
        this.status_code = 500;
        this.message = "Internal Server Error"
    }
    
}